from sys import path
import numpy as np
import odbAccess
from abaqus import *
from abaqusConstants import *
import os
from textRepr import *
from numpy import genfromtxt
import visualization
import animation
import displayGroupOdbToolset as dgo 

def p(pstring):
    prettyPrint(pstring)
    

def ModelViewFunc(render_beams,deflection,scalefactor,x_in_or_out,step):
    
    # from abaqus import *
    
    #deflection=10;
    framerate=100
    
    # find current viewport
    viewport_obj = session.viewports[session.currentViewportName]
    
    # assign odb file from current viewport
    odb_obj = viewport_obj.displayedObject
    
    if x_in_or_out=='In':
        viewport_obj.view.setValues(cameraPosition= (-2390, -2274, 976))
        viewport_obj.view.setValues(cameraUpVector=(0.4, 0.4, 0.82))
        viewport_obj.view.setValues(cameraTarget=(237, 168, 21))
        #viewport_obj.view.setValues(fieldOfViewAngle=(237, 168, 21))
        viewport_obj.view.setValues(nearPlane=2714)
        viewport_obj.view.setValues(farPlane=4101)
        viewport_obj.view.setValues(viewOffsetX=0)
        viewport_obj.view.setValues(viewOffsetY=0)
    elif x_in_or_out=='Out':
        viewport_obj.view.setValues(cameraPosition= (2987, 2000, 1052))
        viewport_obj.view.setValues(cameraUpVector=(-0.36, -0.47, 0.79))
        viewport_obj.view.setValues(cameraTarget= (27, -19, 77))
        viewport_obj.view.setValues(fieldOfViewAngle= 22)
        viewport_obj.view.setValues(viewOffsetX=0)
        viewport_obj.view.setValues(viewOffsetY=0)
        

    # Find step
    stepkeys=odb_obj.steps.keys()
    this_step=odb_obj.steps[stepkeys[step]]

    firstframe=this_step.frames[1]
    disp_field=firstframe.fieldOutputs['U']

    # Calculate scale factor if not provided
    if scalefactor==-1:
        disp_data=this_step.frames[1].fieldOutputs['U'].bulkDataBlocks[0].data
        disp_random_subset=[ [ disp_data[i] ] for i in np.arange(0,int(len(disp_data)),max(int(len(disp_data)/1000),1)) ]
        disp_random_subset=np.array(disp_random_subset).flatten()
        maxdisp=max(abs(disp_random_subset));
        if (maxdisp>0.9) & (maxdisp<1.1):
            maxdisp=1
        scalefactor=deflection/maxdisp    
    
    
    #scalefactor=scalefactor*1.0
    #print(scalefactor)
    viewport_obj.odbDisplay.setPrimaryVariable(field=disp_field,outputPosition=NODAL,refinement=(INVARIANT, 'Magnitude'))
    viewport_obj.odbDisplay.display.setValues(plotState=(CONTOURS_ON_DEF,UNDEFORMED)) #UNDEFORMED

    #view options
    viewport_obj.odbDisplay.setDeformedVariable(disp_field)
    
    viewport_obj.odbDisplay.commonOptions.setValues(deformationScaling=UNIFORM, uniformScaleFactor=scalefactor,visibleEdges=FEATURE)

    viewport_obj.viewportAnnotationOptions.setValues(
        triad=ON, title=OFF, state=ON,  compass=ON,
        legendBox=0,
        legendDecimalPlaces= 2,
        triadPosition= (3, 4),
        legendFont='-*-verdana-medium-r-normal-*-*-80-*-*-p-*-*-*', 
        titleFont='-*-verdana-medium-r-normal-*-*-120-*-*-p-*-*-*', 
        stateFont='-*-verdana-medium-r-normal-*-*-80-*-*-p-*-*-*')
        
    viewport_obj.odbDisplay.contourOptions.setValues(numIntervals=15, maxAutoCompute=ON, minAutoCompute=ON)
    session.animationController.animationOptions.setValues(frameRate=int(framerate),numScaleFactorFrames=15,relativeScaling= FULL_CYCLE,mode=SWING)

    if render_beams=='On':
        viewport_obj.odbDisplay.basicOptions.setValues(beamScaleFactor=1.0, renderBeamProfiles=ON, shellScaleFactor=1.0, renderShellThickness=OFF)
    elif render_beams=='Off':
        viewport_obj.odbDisplay.basicOptions.setValues(beamScaleFactor=1.0, renderBeamProfiles=OFF, shellScaleFactor=1.0, renderShellThickness=OFF)
