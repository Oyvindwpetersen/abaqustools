from sys import path
import numpy as np
import odbAccess
from abaqus import *
from abaqusConstants import *
import os
from textRepr import *
from numpy import genfromtxt
import visualization
import animation
import displayGroupOdbToolset as dgo 

def p(pstring):
    prettyPrint(pstring)
    

def ModalViewFunc(DoRenderBeamProfiles,deflection,X_in_or_out):
    
    # from abaqus import *
    
    #deflection=10;
    frameRate=100
    
    # find current viewport
    myViewport = session.viewports[session.currentViewportName]
    # assign odb file from current viewport
    myOdb = myViewport.displayedObject
    
    if X_in_or_out=='In':
        myViewport.view.setValues(cameraPosition= (-2390, -2274, 976))
        myViewport.view.setValues(cameraUpVector=(0.4, 0.4, 0.82))
        myViewport.view.setValues(cameraTarget=(237, 168, 21))
        #myViewport.view.setValues(fieldOfViewAngle=(237, 168, 21))
        myViewport.view.setValues(nearPlane=2714)
        myViewport.view.setValues(farPlane=4101)
        myViewport.view.setValues(viewOffsetX=0)
        myViewport.view.setValues(viewOffsetY=0)
    elif X_in_or_out=='Out':
        myViewport.view.setValues(cameraPosition= (2987, 2000, 1052))
        myViewport.view.setValues(cameraUpVector=(-0.36, -0.47, 0.79))
        myViewport.view.setValues(cameraTarget= (27, -19, 77))
        myViewport.view.setValues(fieldOfViewAngle= 22)
        myViewport.view.setValues(viewOffsetX=0)
        myViewport.view.setValues(viewOffsetY=0)
        


    stepKeys=myOdb.steps.keys()
    lastStepName=stepKeys[-1]
    firstStepName=stepKeys[0]
    modalStep=myOdb.steps[lastStepName]

    lastFrame=modalStep.frames[-1]
    firstFrame=modalStep.frames[1]
    dispField=firstFrame.fieldOutputs['U']

    # calculate scale factor
    # modeTransValues_Dummy=firstFrame.fieldOutputs['U'].values
    # nodeLabelAll=[ [modeTransValues_Dummy[ii].nodeLabel ] for ii in range(len(modeTransValues_Dummy))]
    modalDisplacement=modalStep.frames[1].fieldOutputs['U'].bulkDataBlocks[0].data
    modalDisplacementRandomSet=[ [ modalDisplacement[i] ] for i in np.arange(0,int(len(modalDisplacement)),max(int(len(modalDisplacement)/1000),1)) ]
    modalDisplacementRandomSet=np.array(modalDisplacementRandomSet).flatten()
    maxDisplacement=max(abs(modalDisplacementRandomSet));
    if (maxDisplacement>0.9) & (maxDisplacement<1.1):
        maxDisplacement=1
        
    
    scaleFactor=deflection/maxDisplacement

    #myViewport.odbDisplay.setDefaultField(dispField)
    myViewport.odbDisplay.setPrimaryVariable(field=dispField,outputPosition=NODAL,refinement=(INVARIANT, 'Magnitude'))
    myViewport.odbDisplay.display.setValues(plotState=(CONTOURS_ON_DEF,UNDEFORMED)) #UNDEFORMED

    #view options
    myViewport.odbDisplay.setDeformedVariable(dispField)

    myViewport.odbDisplay.commonOptions.setValues(deformationScaling=UNIFORM, uniformScaleFactor=scaleFactor,visibleEdges=FEATURE)

    myViewport.viewportAnnotationOptions.setValues(
        triad=ON, title=OFF, state=ON,  compass=ON,
        legendBox=0,
        legendDecimalPlaces= 2,
        triadPosition= (3, 4),
        legendFont='-*-verdana-medium-r-normal-*-*-80-*-*-p-*-*-*', 
        titleFont='-*-verdana-medium-r-normal-*-*-120-*-*-p-*-*-*', 
        stateFont='-*-verdana-medium-r-normal-*-*-80-*-*-p-*-*-*')
        
    myViewport.odbDisplay.contourOptions.setValues(numIntervals=10, maxAutoCompute=ON, minAutoCompute=ON)
    session.animationController.animationOptions.setValues(frameRate=int(frameRate),numScaleFactorFrames=15,relativeScaling= FULL_CYCLE,mode=SWING)

    if DoRenderBeamProfiles=='Yes':
        myViewport.odbDisplay.basicOptions.setValues(beamScaleFactor=1.0, renderBeamProfiles=ON, shellScaleFactor=1.0, renderShellThickness=OFF)
    elif DoRenderBeamProfiles=='No':
        myViewport.odbDisplay.basicOptions.setValues(beamScaleFactor=1.0, renderBeamProfiles=OFF, shellScaleFactor=1.0, renderShellThickness=OFF)
